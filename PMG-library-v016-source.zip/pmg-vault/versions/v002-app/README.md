# PMG Vault v002 · 可运行软件主体

从 v001 完整目录副本开发；v001 未修改。

## 启动

需要 Node.js 22+，无需安装依赖。在本目录执行 `node server.mjs`，打开 http://127.0.0.1:8790 。支持桌面和手机宽度布局。

已实现：IndexedDB 本地藏品库、真实样例导入、卡片/表格、八字段检索与升降序、组合筛选、原图查看/下载、截图与隔离网页快照、历史记录、PMGX v1 ZIP 导入导出、同编号历史合并与整库 ZIP 导出。

原图与存档保存在浏览器资料库中，不发送到云端。清理浏览器数据前务必导出 PMGX 或整库 ZIP。换设备可导入各个 PMGX；整库 ZIP 目前需解压后批量选择 PMGX 导入。

查询页支持中国/全球网站选择和准确官网跳转。**自动浏览器采集、验证码接续、Electron 安装包和原生手机应用尚未实现**。本版目标是可运行的软件主体，不代表采集引擎已完成。

样例是此前人工核实记录；运行 `node scripts/build-sample.mjs` 会从项目外 outputs 已保存资料生成 `PMG-8077301-001.pmgx`。软件缺少该文件时仍可导入自己的档案。个人样例与原图不纳入源码版本。

`node --test tests/core.test.mjs` 验证档案、损坏拒绝、排序、站点映射；`node scripts/check.mjs` 验证封存。未进行真实手机设备、安装包或新在线查询采集测试。

模块：lib/domain.mjs 数据规则，lib/archive.mjs ZIP/PMGX，lib/storage.mjs 持久化，ui/app.mjs 页面，ui/theme.css 主题。UI 不解析官网 HTML。导入上限 96 MB、512 文件；首版只接收数字评分。来源网页不受信任，在禁用脚本和外部请求的隔离视图查看。
